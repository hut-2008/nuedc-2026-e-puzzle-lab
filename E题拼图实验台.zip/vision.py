"""Real image-only calibration, polygon recognition, and independent recapture.

No import of scene.py; no rendering poses/cut polygons are accepted here.
"""
from __future__ import annotations

from dataclasses import dataclass
import itertools
import math
import cv2
import numpy as np
from geometry import area, bounds, clean, centroid, interior_grip, rigid_fit, transform

SCALE=3.
PAPER_W,PAPER_H=210.,297.
DOTS=np.array([(x,y) for y in (20.,148.,277.) for x in (20.,105.,190.)])


def blue_mask(image):
    hsv=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
    broad=cv2.inRange(hsv,np.array([90,65,35],np.uint8),np.array([130,255,255],np.uint8))
    # A court card may contain blue ink. Model the paper's saturation from its
    # dominant pixels instead of deleting every blue pixel inside a piece.
    values=hsv[:,:,1][broad>0]
    threshold=max(65.,float(np.percentile(values,60))-15.) if len(values) else 65.
    return cv2.bitwise_and(broad,np.uint8(hsv[:,:,1]>=threshold)*255)


def order_quad(points):
    p=np.array(points,np.float32).reshape(4,2)
    s=p.sum(axis=1); d=p[:,0]-p[:,1]
    return np.array([p[np.argmin(s)],p[np.argmax(d)],p[np.argmax(s)],p[np.argmin(d)]],np.float32)


@dataclass
class Calibration:
    camera_to_mm: np.ndarray
    quad: np.ndarray
    dot_pixels: np.ndarray
    residuals_mm: np.ndarray
    heldout_rms_mm: float

    def rectify(self,frame):
        return cv2.warpPerspective(frame,np.diag([SCALE,SCALE,1.]) @ self.camera_to_mm,(int(PAPER_W*SCALE),int(PAPER_H*SCALE)))

    def camera_points(self,points):
        return cv2.perspectiveTransform(np.asarray(points,np.float32)[None],np.linalg.inv(self.camera_to_mm))[0]


def calibrate(frame):
    blue=blue_mask(frame)
    contours,_=cv2.findContours(blue,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        raise ValueError('没有检测到蓝色 A4 标定区域')
    contour=max(contours,key=cv2.contourArea)
    q=cv2.approxPolyDP(contour,.015*cv2.arcLength(contour,True),True)
    if len(q)!=4 or cv2.contourArea(q)<30000:
        raise ValueError('A4 四边形不完整，请保证整张纸可见')
    quad=order_quad(q)
    rough=cv2.getPerspectiveTransform(quad,np.float32([[0,0],[210,0],[210,297],[0,297]]))
    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    white=cv2.inRange(hsv,np.array([0,0,150],np.uint8),np.array([179,75,255],np.uint8))
    circles,_=cv2.findContours(white,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    found={}
    for c in circles:
        ar=cv2.contourArea(c); perimeter=cv2.arcLength(c,True)
        if not (35<ar<1800) or 4*math.pi*ar/max(1,perimeter**2)<.65:
            continue
        m=cv2.moments(c)
        pt=np.array([m['m10']/m['m00'],m['m01']/m['m00']],np.float32)
        mm=cv2.perspectiveTransform(pt.reshape(1,1,2),rough)[0,0]
        idx=int(np.argmin(np.linalg.norm(DOTS-mm,axis=1)))
        if np.linalg.norm(DOTS[idx]-mm)<6:
            found[idx]=pt
    if len(found)!=9:
        raise ValueError(f'只检测到 {len(found)}/9 个标定点')
    pixels=np.array([found[i] for i in range(9)])
    training=np.array([0,2,4,6,8]); heldout=np.array([1,3,5,7])
    h,_=cv2.findHomography(pixels[training],DOTS[training],method=0)
    mapped=cv2.perspectiveTransform(pixels.reshape(1,-1,2),h)[0]
    residual=np.linalg.norm(mapped-DOTS,axis=1)
    rms=float(np.sqrt(np.mean(residual[heldout]**2)))
    if rms>2:
        raise ValueError(f'独立校验误差 {rms:.2f} mm 过大')
    return Calibration(h,quad,pixels,residual,rms)


def refine_polygon(contour,approx):
    """Fit each straight edge from contour pixels, then intersect adjacent lines."""
    points=contour.reshape(-1,2).astype(float)
    p=approx.reshape(-1,2).astype(float)
    lines=[]
    for a,b in zip(p,np.roll(p,-1,axis=0)):
        direction=b-a; length=np.linalg.norm(direction)
        unit=direction/length
        along=(points-a)@unit
        perp=np.abs((points[:,0]-a[0])*unit[1]-(points[:,1]-a[1])*unit[0])
        selected=points[(along>length*.12)&(along<length*.88)&(perp<2.5)]
        if len(selected)<3:
            lines.append((a,unit))
        else:
            vx,vy,x,y=cv2.fitLine(selected.astype(np.float32),cv2.DIST_L2,0,.01,.01).flatten()
            lines.append((np.array([x,y]),np.array([vx,vy])))
    out=[]
    for i in range(len(lines)):
        a,u=lines[i-1]; b,v=lines[i]
        matrix=np.column_stack([u,-v])
        if abs(np.linalg.det(matrix))<.06:
            out.append(p[i]); continue
        point=a+np.linalg.solve(matrix,b-a)[0]*u
        # Acute vertices can be truncated several pixels by raster sampling;
        # intersecting the fitted straight edges restores the physical corner.
        out.append(point if np.linalg.norm(point-p[i])<12 else p[i])
    return clean(np.array(out)/SCALE)


@dataclass
class Observation:
    id: int
    polygon: np.ndarray
    grip: np.ndarray
    clearance: float

    def summary(self):
        return {'id':self.id,'vertices':np.round(self.polygon,2).tolist(),
                'centroid':np.round(centroid(self.polygon),2).tolist(),
                'area_mm2':round(area(self.polygon),2),'grip':np.round(self.grip,2).tolist(),
                'grip_clearance_mm':round(self.clearance,2)}


@dataclass
class Detection:
    pieces: list[Observation]
    rectified: np.ndarray
    mask: np.ndarray
    region: str


def detect(frame,calibration,region='upper'):
    rect=calibration.rectify(frame)
    mask=cv2.bitwise_not(blue_mask(rect))
    allowed=np.zeros_like(mask)
    if region in ('upper','all'):
        allowed[6:int(145*SCALE),6:-6]=255
    if region in ('lower','all'):
        allowed[int(152*SCALE):-6,6:-6]=255
    mask=cv2.bitwise_and(mask,allowed)
    # Do not open/erode physical contours: that truncates acute puzzle corners.
    # Speckles are rejected by connected-component area instead.
    contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    candidates=[c for c in contours if cv2.contourArea(c)>80*SCALE**2]
    candidates.sort(key=lambda c:cv2.boundingRect(c)[1]*10000+cv2.boundingRect(c)[0])
    pieces=[]
    for i,c in enumerate(candidates):
        approx=cv2.approxPolyDP(c,1.7,True)
        for eps in (2.1,2.6,3.2):
            if len(approx)<=5:
                break
            approx=cv2.approxPolyDP(c,eps,True)
        # Opening/antialiasing chamfers sharp corners by a few pixels. A chamfer
        # is not an additional physical edge (fixed task's shortest edge is 10mm).
        approx=approx.reshape(-1,2)
        while len(approx)>3:
            lens=np.linalg.norm(np.roll(approx,-1,axis=0)-approx,axis=1)
            k=int(np.argmin(lens))
            if lens[k]>=4*SCALE:
                break
            approx=np.delete(approx,(k+1)%len(approx),axis=0)
        changed=True
        while changed and len(approx)>3:
            changed=False
            for k in range(len(approx)):
                a,b,p=approx[k-1].astype(float),approx[(k+1)%len(approx)].astype(float),approx[k].astype(float)
                u=b-a; v=p-a
                along=np.dot(v,u)/max(1,np.dot(u,u))
                distance=abs(u[0]*v[1]-u[1]*v[0])/max(1,np.linalg.norm(u))
                if 0<along<1 and distance<2.7:
                    approx=np.delete(approx,k,axis=0);changed=True;break
        if not 3<=len(approx)<=5:
            raise ValueError(f'轮廓含 {len(approx)} 个顶点，无法可靠识别为题目多边形')
        p=refine_polygon(c,approx)
        grip,radius=interior_grip(p)
        pieces.append(Observation(i,p,grip,radius))
    return Detection(pieces,rect,mask,region)


COLORS=[(90,230,170),(245,185,70),(140,130,255),(235,190,205)]


def detection_overlay(detection,plans=None):
    out=detection.rectified.copy()
    for p in detection.pieces:
        color=COLORS[p.id%4]; pts=np.round(p.polygon*SCALE).astype(np.int32)
        cv2.polylines(out,[pts],True,color,2,cv2.LINE_AA)
        for pt in pts:
            cv2.circle(out,tuple(pt),4,color,-1,cv2.LINE_AA)
        g=np.round(p.grip*SCALE).astype(int)
        cv2.drawMarker(out,tuple(g),color,cv2.MARKER_CROSS,17,2)
        cv2.putText(out,f'P{p.id} / {len(p.polygon)}v',(int(pts[:,0].min()),int(pts[:,1].min()-7)),cv2.FONT_HERSHEY_SIMPLEX,.53,color,2,cv2.LINE_AA)
    if plans:
        for action in plans:
            pts=np.round(np.array(action['target_polygon'])*SCALE).astype(np.int32)
            cv2.polylines(out,[pts],True,COLORS[action['id']%4],2,cv2.LINE_AA)
            g=np.round(np.array(action['place'])*SCALE).astype(int)
            cv2.putText(out,f"P{action['id']}",tuple(g),cv2.FONT_HERSHEY_SIMPLEX,.55,(255,255,255),2,cv2.LINE_AA)
    return out


def calibration_overlay(frame,calibration):
    out=frame.copy()
    cv2.polylines(out,[np.round(calibration.quad).astype(np.int32)],True,(100,240,180),3,cv2.LINE_AA)
    for i,(pt,error) in enumerate(zip(calibration.dot_pixels,calibration.residuals_mm)):
        x,y=np.round(pt).astype(int); held=i in (1,3,5,7)
        color=(70,190,255) if held else (100,240,180)
        cv2.circle(out,(x,y),11,color,2,cv2.LINE_AA)
        cv2.putText(out,f'{"V" if held else "F"}{i} {error:.2f}mm',(x+13,y),cv2.FONT_HERSHEY_SIMPLEX,.47,color,1,cv2.LINE_AA)
    return out


def texture_recheck_images(before, recaptured, action):
    """Return the aligned images and the pixels used for single-piece comparison."""
    angle=action['angle']; c,s=math.cos(angle),math.sin(angle)
    r=np.array([[c,-s],[s,c]])
    t=np.array(action['place'])-r@np.array(action['pick'])
    predicted=cv2.warpAffine(before,np.column_stack([r,t*SCALE]).astype(np.float32),
                             (recaptured.shape[1],recaptured.shape[0]))
    mask=np.zeros(recaptured.shape[:2],np.uint8)
    cv2.fillPoly(mask,[np.round(np.array(action['target_polygon'])*SCALE).astype(np.int32)],255)
    valid=cv2.erode(mask,np.ones((7,7),np.uint8))>0
    expected=cv2.GaussianBlur(predicted,(5,5),1.1).astype(float)
    actual=cv2.GaussianBlur(recaptured,(5,5),1.1).astype(float)
    if not np.any(valid):
        return None
    expected*=245/max(150.,float(np.percentile(expected[valid],90)))
    actual*=245/max(150.,float(np.percentile(actual[valid],90)))
    ink=(np.min(expected,axis=2)<190)|(np.min(actual,axis=2)<190)
    selection=valid&ink
    return expected, actual, selection


def verify(frame,calibration,actions,before,task):
    """Fresh pixels, not a check that actuator has executed N commands."""
    lower=detect(frame,calibration,'lower')
    upper=detect(frame,calibration,'upper')
    expected=[np.array(a['target_polygon']) for a in actions]
    measured=[o.polygon for o in lower.pieces]
    result={'expected_count':len(expected),'detected_lower':len(measured),'detected_upper':len(upper.pieces),
            'matching':[],'max_vertex_error_mm':None,'compactness':None,'pass':False}
    if len(measured)!=len(expected):
        result['reason']='复检数量不一致：可能存在未搬运、重叠、粘连或轮廓识别失败'
        return result,lower
    n=len(expected)
    best=min(itertools.permutations(range(n)),key=lambda perm:sum(np.linalg.norm(centroid(expected[i])-centroid(measured[perm[i]])) for i in range(n)))
    errors=[]; area_errors=[]
    for i,j in enumerate(best):
        a,b=expected[i],measured[j]
        d=np.linalg.norm(a[:,None,:]-b[None,:,:],axis=2)
        error=max(float(d.min(0).max()),float(d.min(1).max()))
        errors.append(error)
        area_error=abs(area(a)-area(b))/max(area(a),1)
        area_errors.append(area_error)
        result['matching'].append({'planned_id':actions[i]['id'],'observed_id':j,'vertex_error_mm':round(error,3),'area_error_pct':round(area_error*100,2)})
    allp=np.concatenate(measured)
    if task in (2,3,4):
        from seam_audit import measure
        result['seam_audit']=measure(actions,measured,{a['id']:j for a,j in zip(actions,best)})
    box=bounds(allp); compact=sum(area(p) for p in measured)/np.prod(box[2:]-box[:2])
    result['max_vertex_error_mm']=round(max(errors),3)
    result['compactness']=round(float(compact),4)
    expected_box=bounds(np.concatenate(expected))
    expected_compact=sum(area(p) for p in expected)/np.prod(expected_box[2:]-expected_box[:2])
    result['pass']=bool(len(upper.pieces)==0 and (task==1 or (max(errors)<=3.0 and max(area_errors)<.08 and compact>=expected_compact-.035)))
    if task==4:
        photo_errors=[]
        for action in actions:
            images = texture_recheck_images(before.rectified, lower.rectified, action)
            if images is None:
                continue
            expected, actual, selection = images
            error = float(np.mean(np.abs(expected[selection] - actual[selection])) / 255) if np.any(selection) else 0.
            photo_errors.append(error)
        result['piece_texture_errors']=[round(v,4) for v in photo_errors]
        result['pass']=bool(result['pass'] and (not photo_errors or max(photo_errors)<.23))
    result['reason']='教学复检通过（计划位置偏差与接缝端点间距是不同指标）' if result['pass'] else '复检未通过；请检查数量、目标偏差、面积变化或矩形紧凑率'
    audit=result.get('seam_audit',{})
    if audit.get('status')=='over':
        result['pass']=False
        result['reason']='已配对的接缝端点间距超过 20 mm'
    if audit.get('status')=='undetermined':
        result['pass']=False
        result['reason']='无法判定接缝对应关系：'+audit['reason']
    if task==4 and result.get('piece_texture_errors') and max(result['piece_texture_errors'])>=.23:
        result['reason']='复拍图案与搬运前图像预测的图案不一致，图案复检失败'
    if task==1 and result['pass']:
        result['reason']='搬运项复检通过：上半区清空，下半区碎片数量一致'
    result['note']='这是基于可见图像的复检；不能证明不可见的遮挡部分绝无重叠。图案任务另检查逐片预测图案，界面还会再次比较完整牌面模板。'
    return result,lower
