'use strict';
let task=2, state=null, busy=false, running=false;
const $=id=>document.getElementById(id);
const labels={new:'待标定',calibrated:'校准完成',detected:'识别完成',solved:'目标已求解',moving:'正在搬运',moved:'等待复检',verified:'复检完成'};
const notice=(text,kind='')=>{$('notice').textContent=text;$('notice').className=kind;};
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function controls(){
 document.querySelectorAll('button').forEach(b=>b.disabled=busy);
 $('stop').disabled=false;$('stop').hidden=!running;
 if(!busy){
  $('count').disabled=task<3;$('family').disabled=task<3;
  $('detect').disabled=!state||state.heldout_rms_mm===null||state.moved>0;
  $('solve').disabled=!state||!state.detected||state.moved>0;
  $('move').disabled=!state||!state.planned||state.moved>=state.planned;
  $('verify').disabled=!state||!state.planned||state.moved<state.planned;
  $('disturb').disabled=!state||!state.planned||state.moved<state.planned||task===1;
 }
}
function analysisImage(){
 const src=state&&state[$('viewMode').value==='mask'?'mask':'analysis'];
 if(src){$('analysis').src=src;$('placeholder').hidden=true;}
 else{$('analysis').removeAttribute('src');$('placeholder').hidden=false;}
}
function render(data){
 state=data;task=data.task;document.querySelectorAll('[data-task]').forEach(b=>b.classList.toggle('selected',Number(b.dataset.task)===task));$('camera').src=data.camera;analysisImage();$('phase').textContent=labels[data.phase]||data.phase;
 $('calMetric').textContent=data.heldout_rms_mm===null?'—':`${data.heldout_rms_mm.toFixed(3)} mm`;
 $('countMetric').textContent=data.detected===null?'—':`${data.detected} 块 · 已搬 ${data.moved}`;
 $('solveMetric').textContent=data.solver?`${data.solver.elapsed_seconds.toFixed(3)} s`:'—';
 const v=data.verification;
 $('verifyMetric').textContent=v&&v.max_vertex_error_mm!==null?`${v.max_vertex_error_mm.toFixed(2)} mm`:'—';
 $('resultBadge').textContent=v?(v.pass?'通过':'未通过'):(data.solver?'等待搬运 / 复检':'待运行');
 $('resultBadge').className=v?(v.pass?'pass':'fail'):'';
 $('resultText').textContent=v?v.reason:(data.solver?data.solver.method:'识别端只看图像。先检测九点标定板，随后移除标定板，识别随机放置的碎片。');
 const detail=[];
 if(data.solver){detail.push(`几何候选布局：${data.solver.solutions} 个`);detail.push(`预计平面移动距离：${data.solver.travel_mm.toFixed(1)} mm`);}
 if(v){detail.push(`复拍检测：上区 ${v.detected_upper} 块 / 下区 ${v.detected_lower} 块`);if(v.compactness!==null)detail.push(`图像矩形紧凑率：${(v.compactness*100).toFixed(1)}%`);}
 if(v&&v.recapture_texture_error!==undefined)detail.push(`复拍牌面误差：${v.recapture_texture_error.toFixed(3)}`);
 else if(data.solver&&data.solver.texture_error!==undefined)detail.push(`拼接牌面误差：${data.solver.texture_error.toFixed(3)}`);
 $('detailMetrics').replaceChildren(...detail.map(x=>{const d=document.createElement('div');d.textContent=x;return d;}));
 $('messages').replaceChildren(...data.messages.slice().reverse().map(x=>{const li=document.createElement('li');const t=document.createElement('time');t.textContent=x.time;li.append(t,document.createTextNode(x.text));return li;}));
 $('pieces').replaceChildren(...data.observations.map(o=>{
  const a=data.actions.find(x=>x.id===o.id);const row=document.createElement('tr');
  [`P${o.id}`,o.vertices.length,o.area_mm2.toFixed(1),o.grip.map(x=>x.toFixed(1)).join(', '),a?a.place.map(x=>x.toFixed(1)).join(', '):'—',a?`${a.angle_deg}°`:'—'].forEach(x=>{const td=document.createElement('td');td.textContent=x;row.append(td);});return row;
 }));
 controls();
}
async function api(path,body={}){
 const response=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 const data=await response.json();if(!response.ok)throw Error(data.error||'请求失败');render(data);return data;
}
async function action(fn){
 if(busy)return;busy=true;controls();
 try{await fn();if(state.verification)notice(state.verification.reason,state.verification.pass?'success':'error');else notice(`当前阶段：${labels[state.phase]}`);}
 catch(error){notice(error.message,'error');}
 finally{busy=false;controls();}
}
function options(){return {task,seed:Number($('seed').value),count:Number($('count').value),family:$('family').value,noise:Number($('noise').value),slip:Number($('slip').value)};}
document.querySelectorAll('[data-task]').forEach(b=>b.addEventListener('click',()=>action(async()=>{
 task=Number(b.dataset.task);document.querySelectorAll('[data-task]').forEach(t=>t.classList.toggle('selected',t===b));await api('new',options());
})));
$('generate').onclick=()=>action(()=>api('new',options()));
$('shuffle').onclick=()=>action(async()=>{$('seed').value=1+Math.floor(Math.random()*10000);await api('new',options());});
$('calibrate').onclick=()=>action(()=>api('calibrate'));
$('detect').onclick=()=>action(()=>api('detect'));
$('solve').onclick=()=>action(async()=>{notice('正在从识别轮廓搜索拼接方案；复杂切法可能需要十余秒…');await api('solve',{budget:20});});
$('move').onclick=()=>action(()=>api('move'));
$('verify').onclick=()=>action(()=>api('verify'));
$('disturb').onclick=()=>action(()=>api('disturb'));
$('export').onclick=()=>action(async()=>{const data=await api('export');notice(`已保存到：${data.export_path}`,'success');});
$('viewMode').onchange=analysisImage;
$('stop').onclick=()=>{running=false;notice('将在当前处理步骤结束后停止连续演示。');};
$('auto').onclick=()=>action(async()=>{
 running=true;controls();await api('new',options());
 for(const step of ['calibrate','detect','solve']){
  if(!running)return;notice(step==='solve'?'正在搜索几何布局与图案，可能需要十余秒…':`正在${step==='calibrate'?'检测标定点':'识别碎片'}…`);
  await api(step,step==='solve'?{budget:20}:{});await wait(650);
 }
 while(running&&state.moved<state.planned){await api('move');await wait(650);}
 if(running)await api('verify');running=false;
}).finally(()=>{running=false;controls();});
fetch('/api/state').then(r=>r.json()).then(data=>{task=data.task;render(data);notice('准备就绪。点击“一键演示全过程”，或按步骤运行。');}).catch(error=>notice(error.message,'error'));
