"""Local interactive experiment; only Python + OpenCV + NumPy are required."""
from __future__ import annotations

import argparse
import base64
from datetime import datetime
import json
import socket
from pathlib import Path
import threading
import time
import traceback
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import webbrowser

import cv2
import numpy as np

from scene import Scene, card_texture
from vision import calibrate, detect, verify, calibration_overlay, detection_overlay
from solver import solve, texture_score

ROOT=Path(__file__).resolve().parent
PUBLIC_TEMPLATES=[card_texture(120,80,i) for i in range(4)]


def image_url(image):
    if image is None:
        return None
    ok,data=cv2.imencode('.jpg',image,[cv2.IMWRITE_JPEG_QUALITY,91])
    if not ok:
        raise RuntimeError('Image encoding failed')
    return 'data:image/jpeg;base64,'+base64.b64encode(data).decode('ascii')


class Lab:
    def __init__(self):
        self.lock=threading.RLock()
        self.new({})

    def log(self,text):
        self.messages.append({'time':datetime.now().strftime('%H:%M:%S'),'text':text})

    def new(self,options):
        task=int(options.get('task',2));count=int(options.get('count',4))
        if task not in (1,2,3,4) or count not in (1,2,3,4):
            raise ValueError('任务或碎片数量无效')
        family=options.get('family','random')
        if family not in ('random','concave'):
            raise ValueError('未知切割类型')
        noise=max(0.,min(12.,float(options.get('noise',1.2))))
        slip=max(0.,min(3.,float(options.get('slip',.25))))
        self.scene=Scene(task=task,seed=int(options.get('seed',12)),count=count,family=family,noise=noise,slip=slip)
        self.cal=None;self.before=None;self.detection=None;self.actions=[];self.solver_info=None
        self.verification=None;self.step=0;self.phase='new';self.messages=[]
        self.frame=self.scene.render();self.original_frame=self.frame.copy();self.cal_frame=None
        self.camera_view=self.frame;self.analysis=None;self.mask=None
        self.log(f'任务 {task}，种子 {self.scene.seed}；识别端尚未接触任何图像以外的场景信息。')
        return self.payload()

    def do_calibrate(self):
        self.cal_frame=self.scene.render(calibration=True)
        self.cal=calibrate(self.cal_frame)
        self.camera_view=calibration_overlay(self.cal_frame,self.cal)
        self.analysis=self.cal.rectify(self.cal_frame);self.mask=None;self.phase='calibrated'
        self.log(f'检测到 9 个圆点；5 点拟合，4 点独立校验 RMS {self.cal.heldout_rms_mm:.3f} mm。标定板将在识别阶段移除。')
        return self.payload()

    def do_detect(self):
        if self.cal is None:
            raise ValueError('请先完成图像标定')
        if self.step:
            raise ValueError('搬运已开始；请使用复检或重新生成场景')
        self.frame=self.scene.render();self.camera_view=self.frame
        self.detection=detect(self.frame,self.cal,'upper');self.before=self.detection
        if not self.detection.pieces:
            raise ValueError('未识别到碎片')
        self.analysis=detection_overlay(self.detection);self.mask=self.detection.mask
        self.phase='detected';self.actions=[];self.solver_info=None;self.verification=None
        self.log(f'仅从图像识别出 {len(self.detection.pieces)} 块，顶点数 {[len(p.polygon) for p in self.detection.pieces]}。十字为内部抓取点。')
        return self.payload()

    def do_solve(self,options):
        if self.before is None:
            raise ValueError('请先识别上半区碎片')
        if self.step:
            raise ValueError('搬运已开始，不能用旧观测重新求解')
        budget=max(2.,min(45.,float(options.get('budget',16))))
        self.actions,self.solver_info=solve(self.before,self.scene.task,PUBLIC_TEMPLATES,budget)
        self.analysis=detection_overlay(self.before,self.actions);self.phase='solved'
        self.log(f"求解完成：{self.solver_info['method']}；耗时 {self.solver_info['elapsed_seconds']:.3f}s，候选布局 {self.solver_info['solutions']}。")
        if self.scene.task==4:
            self.log(f"牌面由 4 张自绘参考模板比较选出，图像误差 {self.solver_info['texture_error']:.3f}；没有使用真实切割/位姿。")
        return self.payload()

    def do_move(self):
        if not self.actions:
            raise ValueError('请先求解目标位置')
        if self.step>=len(self.actions):
            raise ValueError('所有碎片已搬运，请进行二次检测')
        action=self.actions[self.step]
        self.scene.place(action);self.step+=1
        self.frame=self.scene.render();self.camera_view=self.frame
        # This is a fresh recognition, not the original polygons redrawn in place.
        try:
            self.detection=detect(self.frame,self.cal,'all')
            self.analysis=detection_overlay(self.detection,self.actions)
            self.mask=self.detection.mask
        except ValueError as error:
            self.analysis=self.cal.rectify(self.frame)
            self.log(f'搬运后即时轮廓检查：{error}')
        self.phase='moved' if self.step==len(self.actions) else 'moving'
        self.log(f"已执行 P{action['id']}：旋转 {action['angle_deg']:.1f}°，目标 ({action['place'][0]:.1f}, {action['place'][1]:.1f}) mm；重新采集图像。")
        return self.payload()

    def do_verify(self):
        if not self.actions or self.step<len(self.actions):
            raise ValueError('请先完成全部搬运')
        self.frame=self.scene.render();self.camera_view=self.frame
        self.verification,self.detection=verify(self.frame,self.cal,self.actions,self.before,self.scene.task)
        if self.scene.task==4 and self.detection.pieces:
            poses=[(0.,np.zeros(2)) for _ in self.detection.pieces]
            error,index=texture_score(self.detection,poses,PUBLIC_TEMPLATES)
            self.verification['recapture_texture_error']=round(error,4)
            self.verification['recapture_template_index']=index
            self.verification['pass']=bool(self.verification['pass'] and error<.30)
            if error>=.30:
                self.verification['reason']='复拍牌面与参考模板不一致，花纹复检失败'
        self.analysis=detection_overlay(self.detection);self.mask=self.detection.mask;self.phase='verified'
        self.log(self.verification['reason'])
        return self.payload()

    def disturb(self):
        if not self.actions or self.step<len(self.actions):
            raise ValueError('完成搬运后才可注入偏移')
        self.scene.pieces[0].translation+=np.array([6.,0.])
        self.frame=self.scene.render();self.camera_view=self.frame;self.phase='moved';self.verification=None
        self.analysis=self.cal.rectify(self.frame)
        self.log('已人为给一个物理碎片增加 6 mm 偏移；求解目标没有改变，请再次检测。')
        return self.payload()

    def export(self):
        directory=ROOT/'runs'/datetime.now().strftime(f'%Y%m%d-%H%M%S-task{self.scene.task}-seed{self.scene.seed}')
        directory.mkdir(parents=True,exist_ok=True)
        cv2.imwrite(str(directory/'before.png'),self.original_frame)
        cv2.imwrite(str(directory/'latest.png'),self.frame)
        if self.cal_frame is not None:
            cv2.imwrite(str(directory/'calibration.png'),self.cal_frame)
        if self.analysis is not None:
            cv2.imwrite(str(directory/'recognized.png'),self.analysis)
        report=self.metrics()
        report['actions']=self.actions
        report['input_observations']=[] if self.before is None else [o.summary() for o in self.before.pieces]
        if self.cal:
            report['camera_to_mm']=self.cal.camera_to_mm.tolist()
        report['messages']=self.messages
        (directory/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        self.log(f'图像、标定矩阵、识别坐标与报告已保存到 {directory}')
        return {**self.payload(),'export_path':str(directory)}

    def metrics(self):
        return {'app':'puzzle_lab','task':self.scene.task,'seed':self.scene.seed,'phase':self.phase,'moved':self.step,
                'planned':len(self.actions),'heldout_rms_mm':None if self.cal is None else round(self.cal.heldout_rms_mm,4),
                'detected':None if self.before is None else len(self.before.pieces),
                'solver':self.solver_info,'verification':self.verification}

    def payload(self):
        return {**self.metrics(),'camera':image_url(self.camera_view),'analysis':image_url(self.analysis),
                'mask':image_url(self.mask),'messages':self.messages[-30:],
                'observations':[] if self.before is None else [o.summary() for o in self.before.pieces],
                'live_observations':[] if self.detection is None else [o.summary() for o in self.detection.pieces],
                'actions':self.actions,
                'calibration':None if self.cal is None else {'residuals_mm':self.cal.residuals_mm.tolist(),'fit_indices':[0,2,4,6,8],'heldout_indices':[1,3,5,7]}}


class Handler(BaseHTTPRequestHandler):
    lab:Lab

    def log_message(self,fmt,*args):
        if len(args)>1 and str(args[1])!='200':
            super().log_message(fmt,*args)

    def send(self,data,content_type='application/json; charset=utf-8',status=200):
        if not isinstance(data,bytes):
            data=json.dumps(data,ensure_ascii=False,allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers();self.wfile.write(data)

    def do_GET(self):
        route=self.path.split('?')[0]
        files={'/':('index.html','text/html; charset=utf-8'),'/app.js':('app.js','text/javascript; charset=utf-8'),'/style.css':('style.css','text/css; charset=utf-8')}
        if route in files:
            name,mime=files[route];self.send((ROOT/'web'/name).read_bytes(),mime)
        elif route=='/health':
            self.send({'app':'puzzle_lab'})
        elif route=='/api/state':
            with self.lab.lock:
                self.send(self.lab.payload())
        elif route.startswith('/source/') and route[8:] in ('scene.py','vision.py','solver.py','geometry.py','app.py','README.md'):
            self.send((ROOT/route[8:]).read_bytes(),'text/plain; charset=utf-8')
        elif route=='/favicon.ico':
            self.send(b'','image/x-icon',204)
        else:
            self.send({'error':'Not found'},status=404)

    def do_POST(self):
        origin=self.headers.get('Origin')
        if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'):
            self.send({'error':'Unexpected origin'},status=403);return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>10000:
                raise ValueError('Request too large')
            options=json.loads(self.rfile.read(length) or b'{}')
            with self.lab.lock:
                methods={'/api/new':lambda:self.lab.new(options),'/api/calibrate':self.lab.do_calibrate,
                         '/api/detect':self.lab.do_detect,'/api/solve':lambda:self.lab.do_solve(options),
                         '/api/move':self.lab.do_move,'/api/verify':self.lab.do_verify,
                         '/api/disturb':self.lab.disturb,'/api/export':self.lab.export}
                if self.path not in methods:
                    self.send({'error':'Not found'},status=404);return
                self.send(methods[self.path]())
        except Exception as error:
            traceback.print_exc()
            self.send({'error':str(error)},status=400)


class LocalServer(ThreadingHTTPServer):
    allow_reuse_address=True


def main():
    parser=argparse.ArgumentParser(description='E puzzle recognition/calibration simulation')
    parser.add_argument('--port',type=int,default=8769)
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    url=f'http://127.0.0.1:{args.port}'
    # Probe first: on Windows SO_REUSEADDR alone does not prevent two listeners.
    probe=socket.socket();probe.settimeout(.5)
    occupied=probe.connect_ex(('127.0.0.1',args.port))==0;probe.close()
    if occupied:
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for endpoint in ('/health','/api/state'):
            try:
                existing=json.loads(opener.open(url+endpoint,timeout=3).read())
                if existing.get('app')=='puzzle_lab':
                    print(f'Already running: {url}',flush=True)
                    if not args.no_browser:
                        webbrowser.open(url)
                    return
            except Exception:
                continue
        raise RuntimeError(f'Port {args.port} is used by another application; try --port 8770')
    Handler.lab=Lab()
    try:
        server=LocalServer(('127.0.0.1',args.port),Handler)
    except OSError:
        # A second double-click opens our existing app instead of another server.
        try:
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            existing=json.loads(opener.open(url+'/health',timeout=3).read())
            if existing.get('app')!='puzzle_lab':
                raise ValueError('Port is used by another application')
        except Exception:
            raise RuntimeError(f'Port {args.port} is busy; try --port 8770')
        print(f'Already running: {url}',flush=True)
        if not args.no_browser:
            webbrowser.open(url)
        return
    print(f'Puzzle vision lab: {url}\nKeep this window open. Press Ctrl+C to stop.',flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__=='__main__':
    main()
