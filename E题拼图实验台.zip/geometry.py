"""Small polygon geometry routines written for this experiment (units: mm)."""
from __future__ import annotations

import math
import cv2
import numpy as np


def area(poly):
    p = np.asarray(poly, dtype=float)
    return float(np.sum(p[:, 0] * np.roll(p[:, 1], -1) - p[:, 1] * np.roll(p[:, 0], -1)) / 2)


def clean(poly, tol=1e-5):
    out = []
    for v in np.asarray(poly, dtype=float):
        if not out or np.linalg.norm(v - out[-1]) > tol:
            out.append(v)
    if len(out) > 1 and np.linalg.norm(out[0] - out[-1]) < tol:
        out.pop()
    p = np.asarray(out)
    if len(p) >= 3:
        keep = []
        for i in range(len(p)):
            a, b = p[i] - p[i-1], p[(i+1) % len(p)] - p[i]
            cross = a[0]*b[1] - a[1]*b[0]
            if abs(cross) > tol * max(1, np.linalg.norm(a) + np.linalg.norm(b)):
                keep.append(p[i])
        p = np.asarray(keep)
    return p if area(p) >= 0 else p[::-1].copy()


def rotation(angle):
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, -s], [s, c]], dtype=float)


def transform(poly, angle, translation):
    return np.asarray(poly) @ rotation(angle).T + np.asarray(translation)


def bounds(poly):
    p = np.asarray(poly)
    return np.r_[p.min(axis=0), p.max(axis=0)]


def centroid(poly):
    m = cv2.moments(np.asarray(poly, np.float32))
    return np.array([m['m10']/m['m00'], m['m01']/m['m00']])


def contains(poly, point):
    return cv2.pointPolygonTest(np.asarray(poly, np.float32), tuple(map(float, point)), False) >= 0


def separation(a,b):
    if overlap(a,b)>.01:
        return 0.
    return min([abs(cv2.pointPolygonTest(np.asarray(b,np.float32),tuple(map(float,p)),True)) for p in a]
               +[abs(cv2.pointPolygonTest(np.asarray(a,np.float32),tuple(map(float,p)),True)) for p in b])


def triangles(poly):
    """Ear clipping, including concave five-sided pieces; no convex-hull shortcut."""
    p = clean(poly)
    if len(p) == 3:
        return [p]
    if cv2.isContourConvex(p.astype(np.float32)):
        return [np.array([p[0], p[i], p[i+1]]) for i in range(1, len(p)-1)]
    idx, out = list(range(len(p))), []
    for _ in range(len(p)**2):
        if len(idx) == 3:
            out.append(p[idx])
            return out
        found = False
        for j in range(len(idx)):
            a, b, c = idx[j-1], idx[j], idx[(j+1) % len(idx)]
            tri = p[[a, b, c]]
            if area(tri) <= 1e-8:
                continue
            if any(contains(tri, p[k]) for k in idx if k not in (a, b, c)):
                continue
            out.append(tri)
            idx.pop(j)
            found = True
            break
        if not found:
            raise ValueError('Cannot triangulate a degenerate/self-intersecting contour')
    raise ValueError('Triangulation did not finish')


def overlap(a, b):
    aa, bb = bounds(a), bounds(b)
    if min(aa[2], bb[2]) <= max(aa[0], bb[0])+1e-5 or min(aa[3], bb[3]) <= max(aa[1], bb[1])+1e-5:
        return 0.0
    if cv2.isContourConvex(np.asarray(a, np.float32)) and cv2.isContourConvex(np.asarray(b, np.float32)):
        value=max(0., float(cv2.intersectConvexConvex(np.asarray(a, np.float32), np.asarray(b, np.float32))[0]))
        # OpenCV's float32 clip can return zero for nearly coincident nested
        # boundaries. Recheck containment and clip that case in float64.
        if value<.01 and (contains(a,np.asarray(b).mean(0)) or contains(b,np.asarray(a).mean(0))):
            clipped=np.asarray(a,dtype=float)
            other=clean(b)
            for p,q in zip(other,np.roll(other,-1,axis=0)):
                edge=q-p; normal=np.array([-edge[1],edge[0]])
                clipped=clip_halfplane(clipped,normal,np.dot(p,normal))
                if len(clipped)<3:
                    return 0.
            value=abs(area(clipped))
        return value
    return sum(max(0., float(cv2.intersectConvexConvex(x.astype(np.float32), y.astype(np.float32))[0])) for x in triangles(a) for y in triangles(b))


def clip_halfplane(poly, normal, offset, positive=True):
    p, out = np.asarray(poly), []
    sign = 1 if positive else -1
    for a, b in zip(p, np.roll(p, -1, axis=0)):
        da, db = sign*(np.dot(a, normal)-offset), sign*(np.dot(b, normal)-offset)
        if da >= -1e-8:
            out.append(a)
        if (da < -1e-8) != (db < -1e-8):
            out.append(a + (b-a)*da/(da-db))
    return clean(out) if len(out) >= 3 else np.empty((0, 2))


def interior_grip(poly, radius=2.3):
    """Largest-inscribed-circle center on a 0.5 mm grid, never bbox center."""
    p = np.asarray(poly)
    lo, hi = p.min(0)-2, p.max(0)+2
    mask = np.zeros((int(np.ceil((hi[1]-lo[1])*2))+1, int(np.ceil((hi[0]-lo[0])*2))+1), np.uint8)
    cv2.fillPoly(mask, [np.round((p-lo)*2).astype(np.int32)], 255)
    dist = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
    _, value, _, pos = cv2.minMaxLoc(dist)
    if value/2 < radius:
        raise ValueError('No interior point with enough pickup clearance')
    return lo + np.array(pos)/2, value/2


def rigid_fit(source, target):
    a, b = np.asarray(source), np.asarray(target)
    ca, cb = a.mean(0), b.mean(0)
    u, _, vt = np.linalg.svd((a-ca).T @ (b-cb))
    r = vt.T @ u.T
    if np.linalg.det(r) < 0:
        vt[-1] *= -1
        r = vt.T @ u.T
    return math.atan2(r[1, 0], r[0, 0]), cb-r@ca
