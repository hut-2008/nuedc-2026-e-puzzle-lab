"""Functional/negative tests, not scripts that substitute a hidden answer."""
from __future__ import annotations
import json
from pathlib import Path
import unittest
import cv2
import numpy as np
from geometry import area,overlap,triangles
from scene import Scene,card_texture
from vision import calibrate,detect,verify
from solver import solve


def pipeline(task,seed=12,count=4,family='random',budget=20):
    scene=Scene(task=task,seed=seed,count=count,family=family)
    calibration=calibrate(scene.render(True))
    # Cross an encoded-image boundary: no contours/poses travel through it.
    _,encoded=cv2.imencode('.png',scene.render())
    observations=detect(cv2.imdecode(encoded,cv2.IMREAD_COLOR),calibration)
    actions,info=solve(observations,task,[card_texture(120,80,i) for i in range(4)],budget)
    for action in actions:
        scene.place(action)
    result,recaptured=verify(scene.render(),calibration,actions,observations,task)
    return scene,calibration,observations,actions,info,result,recaptured


class PipelineTests(unittest.TestCase):
    def test_nested_polygon_overlap(self):
        a=np.array([[0,0],[100,0],[100,30],[0,30]],float)
        b=np.array([[0,0],[40,0],[40,50],[0,50]],float)
        self.assertAlmostEqual(overlap(a,b),1200.,places=2)

    def test_concave_triangulation(self):
        p=np.array([[0,0],[110,0],[55,35],[110,70],[0,70]],float)
        self.assertAlmostEqual(sum(area(t) for t in triangles(p)),area(p),places=5)

    def test_blank_calibration_rejected(self):
        with self.assertRaises(ValueError):
            calibrate(np.full((1000,1000,3),255,np.uint8))

    def test_calibration_heldout_points(self):
        scene=Scene(seed=77)
        calibration=calibrate(scene.render(True))
        self.assertLess(calibration.heldout_rms_mm,.5)
        self.assertEqual(calibration.residuals_mm.shape,(9,))

    def test_task1_transport_only(self):
        scene,_,_,_,_,result,_=pipeline(1)
        self.assertTrue(result['pass'],result)
        self.assertTrue(scene.physical_metrics()['oracle_all_lower'])

    def test_task2_prescribed_geometry(self):
        scene,_,_,_,_,result,_=pipeline(2)
        self.assertTrue(result['pass'],result)
        self.assertLess(scene.physical_metrics()['oracle_overlap_mm2'],.2)

    def test_task3_unknown_rectangular_cut(self):
        scene,_,_,_,_,result,_=pipeline(3)
        self.assertTrue(result['pass'],result)
        self.assertLess(scene.physical_metrics()['oracle_overlap_mm2'],.2)

    def test_task3_unknown_oblique_cut(self):
        scene,_,_,_,_,result,_=pipeline(3,seed=3)
        self.assertTrue(result['pass'],result)
        self.assertLess(scene.physical_metrics()['oracle_overlap_mm2'],.2)

    def test_task4_texture_from_pixels(self):
        scene,_,_,_,info,result,recaptured=pipeline(4)
        self.assertTrue(result['pass'],result)
        self.assertLess(info['texture_error'],.2)
        # Verify the newly captured pixels against the public art bank as well.
        from solver import texture_score
        error,_=texture_score(recaptured,[(0.,np.zeros(2)) for _ in recaptured.pieces],[card_texture(120,80,i) for i in range(4)])
        self.assertLess(error,.30)

    def test_recapture_detects_wrong_placement(self):
        scene,cal,before,actions,_,result,_=pipeline(2)
        self.assertTrue(result['pass'])
        scene.pieces[0].translation+=np.array([6.,0.])
        failed,_=verify(scene.render(),cal,actions,before,2)
        self.assertFalse(failed['pass'],failed)


if __name__=='__main__':
    unittest.main(verbosity=2)
