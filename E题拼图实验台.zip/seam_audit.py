"""Plan-derived seam correspondences. Supplemental measurement, not a judge."""
import itertools
import numpy as np

def plan_seams(polys):
    seams=[]
    for i,j in itertools.combinations(range(len(polys)),2):
        p,q=polys[i],polys[j]
        for k,(a,b) in enumerate(zip(p,np.roll(p,-1,axis=0))):
            u=b-a; L=np.linalg.norm(u);u=u/L
            for m,(c,d) in enumerate(zip(q,np.roll(q,-1,axis=0))):
                v=d-c; M=np.linalg.norm(v);v=v/M
                if u@v>-.985:continue
                sc,sd=(c-a)@u,(d-a)@u
                lo,hi=max(0.,sd),min(L,sc)
                if hi-lo<4:continue
                endpoints=[]
                for x in (lo,hi):
                    ta=float(x/L);tb=float(np.clip((x-sc)/(sd-sc),0,1))
                    A=a+ta*(b-a);B=c+tb*(d-c)
                    if np.linalg.norm(A-B)>2.5:break
                    endpoints.append([ta,tb])
                if len(endpoints)==2:seams.append(dict(i=i,j=j,k=k,m=m,ends=endpoints))
    return seams

def measure(actions, observed, matching):
    """Use planned labels; cyclically pair measured vertices, not nearest across the gap."""
    def unavailable(why):return dict(status='undetermined',reason=why)
    if not actions or len(observed)!=len(actions):return unavailable('块数不一致')
    if len(actions)==1:return dict(status='not_applicable',rows=[],reason='单块没有相邻接缝')
    aligned={}
    for a in actions:
        idx=a['id'];p=np.asarray(a['target_polygon']);q=np.asarray(observed[matching[idx]])
        if len(p)!=len(q):return unavailable('角点数量变化，不能可靠编号')
        options=sorted(((np.linalg.norm(p-t,axis=1).mean(),n,t) for n,t in enumerate(
            np.roll(z,k,axis=0) for z in (q,q[::-1]) for k in range(len(q)))),key=lambda x:x[0])
        if options[1][0]-options[0][0]<.5:return unavailable('角点配对不唯一')
        aligned[idx]=options[0][2]
    rows=[]
    for act in actions:
        for s in act.get('seams',[]):
            p,q=aligned[s['i']],aligned[s['j']]
            k,m=s['k'],s['m']
            edge=p[(k+1)%len(p)]-p[k]
            edge_length=np.linalg.norm(edge)
            if edge_length < 1e-6:
                return unavailable('接缝边太短，无法估计横向缝宽')
            normal=np.array([-edge[1],edge[0]])/edge_length
            for ta,tb in s['ends']:
                pa=p[k]*(1-ta)+p[(k+1)%len(p)]*ta
                pb=q[m]*(1-tb)+q[(m+1)%len(q)]*tb
                perpendicular = float((pb-pa)@normal)
                foot = pb - perpendicular*normal
                rows.append(dict(i=s['i'],j=s['j'],A=pa.tolist(),B=pb.tolist(),H=foot.tolist(),mm=float(np.linalg.norm(pa-pb)),normal_mm=abs(perpendicular),virtual=bool(min(ta,1-ta)*edge_length>2.5 or min(tb,1-tb)*np.linalg.norm(q[m]-q[(m+1)%len(q)])>2.5)))
    if not rows:return unavailable('未建立接缝对应关系')
    return dict(status='within' if max(r['mm'] for r in rows)<=20 else 'over',rows=rows)
