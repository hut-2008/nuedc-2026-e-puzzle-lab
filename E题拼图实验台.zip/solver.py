"""Original small-polygon puzzle solver. Inputs are image observations ONLY.

Known-task templates are taken from the problem's published figure 2. Unknown
tasks do not receive those templates or any generator cut/pose/seed information.
The bounded beam search reports failure instead of reading a hidden solution.
"""
from __future__ import annotations

import itertools
import math
import time
import cv2
import numpy as np
from geometry import area, bounds, centroid, overlap, rigid_fit, rotation, transform


def known_templates():
    return [np.array(p,float) for p in [
        [(0,0),(20,0),(36,12),(0,20)],
        [(0,20),(36,12),(76,42),(0,30)],
        [(0,30),(76,42),(100,60),(0,60)],
        [(20,0),(100,0),(100,60)],
    ]]


def fixed_solution(observations, trace=None):
    templates=known_templates()
    if len(observations)!=4:
        raise ValueError('固定四片任务必须识别出四块碎片')
    fits={}
    for i,obs in enumerate(observations):
        for j,target in enumerate(templates):
            if len(obs.polygon)!=len(target):
                continue
            candidates=[]
            for shift in range(len(target)):
                q=np.roll(target,shift,axis=0)
                angle,t=rigid_fit(obs.polygon,q)
                error=float(np.sqrt(np.mean(np.sum((transform(obs.polygon,angle,t)-q)**2,axis=1))))
                candidates.append((error,angle,t))
            fits[i,j]=min(candidates,key=lambda x:x[0])
    best=None
    for perm in itertools.permutations(range(4)):
        if not all((i,j) in fits for i,j in enumerate(perm)):
            continue
        error=sum(fits[i,j][0] for i,j in enumerate(perm))
        if best is None or error<best[0]:
            best=(error,perm)
    if best is None or best[0]>8:
        raise ValueError('观测形状与题图四片不匹配；不能套用固定模板')
    poses=[(fits[i,j][1],fits[i,j][2]) for i,j in enumerate(best[1])]
    if trace is not None:
        trace['fixed_matches'] = [
            {'piece_id': observations[i].id, 'template_index': j, 'vertex_rms_mm': fits[i, j][0]}
            for i, j in enumerate(best[1])
        ]
    return poses,{'method':'题图模板 + 循环顶点配准 + 全排列分配','fit_rms_sum_mm':round(best[0],3),'expanded':0,'solutions':1}


def rectangle_error(polys):
    pts=np.concatenate(polys); b=bounds(pts); dims=b[2:]-b[:2]
    a=sum(area(p) for p in polys)
    return max(0.,(float(np.prod(dims))-a)/a),dims


def contact_poses(poly,placed):
    """Collinear contact candidates, including unequal-edge/T-junction offsets."""
    seen=set()
    for boundary in placed:
        for a,b in zip(boundary,np.roll(boundary,-1,axis=0)):
            u=b-a; length=np.linalg.norm(u)
            direction=math.atan2(u[1],u[0])
            for c,d in zip(poly,np.roll(poly,-1,axis=0)):
                v=d-c
                angle=direction-math.atan2(v[1],v[0])+math.pi
                r=rotation(angle)
                rc,rd=r@c,r@d
                translations=[b-rc,a-rd,a-rc,b-rd,(a+b-rc-rd)/2]
                # Existing vertices can split a long common boundary into parts.
                unit=u/length
                for old in placed:
                    for point in old:
                        delta=point-a
                        if abs(u[0]*delta[1]-u[1]*delta[0]) / length < .8:
                            proj=a+unit*np.dot(point-a,unit)
                            translations.extend([proj-rc,proj-rd])
                for t in translations:
                    key=(round(math.cos(angle),3),round(math.sin(angle),3),round(t[0],1),round(t[1],1))
                    if key not in seen:
                        seen.add(key)
                        yield angle,t


def _unconstrained_search(observations,seconds=12.,beam_width=22,need_many=False):
    if not 1<=len(observations)<=4:
        raise ValueError('未知拼图必须包含 1～4 块')
    start=time.perf_counter(); expanded=0
    source=[o.polygon for o in observations]
    root=int(np.argmax([area(p) for p in source])); n=len(source)
    total=sum(area(p) for p in source)
    candidates=[]; final_seen=set()
    rootp=source[root]
    for a,b in zip(rootp,np.roll(rootp,-1,axis=0)):
        angle=-math.atan2(*(b-a)[::-1])
        rotated=transform(rootp,angle,[0,0]); offset=-rotated.min(0)
        poses={root:(angle,offset)}; polys={root:rotated+offset}
        beam=[(0.,poses,polys)]
        for depth in range(1,n):
            next_states=[]; state_seen=set()
            for _,poses,polys in beam:
                if time.perf_counter()-start>seconds:
                    break
                old=list(polys.values())
                for i in range(n):
                    if i in poses:
                        continue
                    for ang,t in contact_poses(source[i],old):
                        expanded+=1
                        q=transform(source[i],ang,t)
                        combined=old+[q]
                        box=bounds(np.concatenate(combined)); dims=box[2:]-box[:2]
                        if max(dims)>122 or min(dims)>92:
                            continue
                        overlaps=[overlap(q,p) for p in old]
                        if any(x>max(7.,.009*min(area(q),area(p))) for x,p in zip(overlaps,old)):
                            continue
                        key=tuple(sorted((k,round(v[0],2),round(v[1][0],1),round(v[1][1],1)) for k,v in {**poses,i:(ang,t)}.items()))
                        if key in state_seen:
                            continue
                        state_seen.add(key)
                        score=(np.prod(dims)-sum(area(p) for p in combined)+sum(overlaps)*8)/total
                        next_states.append((float(score),{**poses,i:(ang,t)},{**polys,i:q}))
            next_states.sort(key=lambda x:x[0])
            beam=next_states[:beam_width]
            if not beam:
                break
        for _,poses,polys in beam:
            if len(poses)!=n:
                continue
            error,dims=rectangle_error(list(polys.values()))
            values=list(polys.values())
            if any(overlap(values[i],values[j])>max(7.,.009*min(area(values[i]),area(values[j]))) for i in range(n) for j in range(i)):
                continue
            if error>.045 or max(dims)>122 or min(dims)>92 or max(dims)<88 or min(dims)<48:
                continue
            lo=np.concatenate(list(polys.values())).min(0)
            normalized=[(poses[i][0],poses[i][1]-lo) for i in range(n)]
            key=tuple((round(ang,2),round(t[0],0),round(t[1],0)) for ang,t in normalized)
            if key in final_seen:
                continue
            final_seen.add(key)
            candidates.append((error,normalized))
        if candidates and not need_many:
            break
        if time.perf_counter()-start>seconds:
            break
    candidates.sort(key=lambda x:x[0])
    if not candidates:
        raise ValueError(f'在 {seconds:g}s 搜索预算内没有找到可靠矩形；程序没有读取生成器答案。可换种子或提高搜索预算。')
    return candidates,{'method':'边接触候选（含长短边）+ 限时束搜索','expanded':expanded,'solutions':len(candidates),
                       'geometry_error':round(candidates[0][0],5),'search_seconds':round(time.perf_counter()-start,3),
                       'bounded_search':True}


def corner_poses(poly,w,h,only_origin=False):
    corners=[np.array([0.,0.])] if only_origin else [np.array([0.,0.]),np.array([w,0.]),np.array([0.,h]),np.array([w,h])]
    seen=set()
    for k in range(len(poly)):
        edge=poly[(k+1)%len(poly)]-poly[k]
        base=math.atan2(edge[1],edge[0])
        for direction in (0.,math.pi/2,math.pi,3*math.pi/2):
            angle=direction-base; r=rotation(angle)
            for endpoint in (poly[k],poly[(k+1)%len(poly)]):
                for corner in corners:
                    t=corner-r@endpoint
                    key=(round(angle% (2*math.pi),3),round(t[0],2),round(t[1],2))
                    if key not in seen:
                        seen.add(key);yield angle,t


def rectangular_packing(observations,need_many=False,seconds=5.):
    """Fast path selected from measured right angles, not the generator family."""
    polygons=[o.polygon for o in observations]
    if any(len(p)!=4 for p in polygons):
        return []
    for p in polygons:
        e=np.roll(p,-1,axis=0)-p
        cosine=np.sum(e*np.roll(e,-1,axis=0),axis=1)/(np.linalg.norm(e,axis=1)*np.linalg.norm(np.roll(e,-1,axis=0),axis=1))
        if np.max(abs(cosine))>.06:
            return []
    options=[];lengths=[]
    for p in polygons:
        edges=np.roll(p,-1,axis=0)-p
        base=math.atan2(edges[0,1],edges[0,0])
        choices=[]
        for k in range(4):
            ang=-base+k*math.pi/2
            q=transform(p,ang,[0,0]);lo=q.min(0);size=q.max(0)-lo
            choices.append((ang,-lo,size))
            lengths.extend(size.tolist())
        options.append(choices)
    total=sum(area(p) for p in polygons); n=len(polygons);widths=[]
    for count in range(1,n+1):
        for group in itertools.combinations(range(n),count):
            for orientations in itertools.product(range(2),repeat=count):
                value=sum(options[i][o][2][0] for i,o in zip(group,orientations))
                if 89<value<121 and 48<total/value<92 and not any(abs(value-v)<.25 for v in widths):
                    widths.append(value)
    widths.sort(key=lambda x: min(abs(x-v) for v in lengths))
    result=[];seen=set();start=time.perf_counter()
    for w in widths:
        h=total/w
        def visit(placed,poses,rects):
            if len(result)>192 or time.perf_counter()-start>seconds:
                return
            if len(placed)==n:
                polys=[transform(polygons[i],*poses[i]) for i in range(n)]
                err,dims=rectangle_error(polys)
                if err>.035:
                    return
                key=tuple((round(v[0]%(2*math.pi),2),round(v[1][0]),round(v[1][1])) for _,v in sorted(poses.items()))
                if key not in seen:
                    seen.add(key);result.append((err,[poses[i] for i in range(n)]))
                return
            for i in range(n):
                if i in placed:
                    continue
                for ang,t,size in options[i]:
                    xs=sorted(set([0.]+[r[2] for r in rects]));ys=sorted(set([0.]+[r[3] for r in rects]))
                    for y in ys:
                        for x in xs:
                            box=(x,y,x+size[0],y+size[1])
                            if box[2]>w+1.2 or box[3]>h+1.2:
                                continue
                            if any(min(box[2],r[2])-max(box[0],r[0])>.05 and min(box[3],r[3])-max(box[1],r[1])>.05 for r in rects):
                                continue
                            visit(placed|{i},{**poses,i:(ang,t+np.array([x,y]))},rects+[box])
                            if result and not need_many:
                                return
        visit(set(),{},[])
        if result and (not need_many or len(result)>=96):
            break
        if time.perf_counter()-start>seconds:
            break
    return sorted(result,key=lambda x:x[0])


def unknown_solutions(observations,seconds=12.,beam_width=36,need_many=False,trace=None):
    """Hypothesize rectangle size from measured boundary segments, then pack.

    Every external side is a sum of at most four measured piece edges in these
    small dissection tasks. Area supplies the other dimension. This is a bounded
    numerical search, not a claim of completeness for all noisy polygon inputs.
    """
    if not 1<=len(observations)<=4:
        raise ValueError('未知拼图必须包含 1～4 块')
    source=[o.polygon for o in observations]; n=len(source)
    fast_start=time.perf_counter()
    packed=rectangular_packing(observations,need_many,min(5.,seconds*.5))
    if packed:
        return packed,{'method':'图像判定正交四边形 + 矩形装箱约束搜索','expanded':0,'solutions':len(packed),
                       'geometry_error':round(packed[0][0],5),'search_seconds':round(time.perf_counter()-fast_start,3),'bounded_search':True}
    total=sum(area(p) for p in source)
    lengths=sorted([round(float(x),1) for p in source for x in np.linalg.norm(np.roll(p,-1,axis=0)-p,axis=1)],reverse=True)
    lengths=lengths[:20]
    hypotheses={}
    for count in range(1,min(n,4)+1):
        for combo in itertools.combinations(range(len(lengths)),count):
            w=sum(lengths[i] for i in combo); h=total/w
            if 89<=w<=121 and 48<=h<=92:
                key=round(w*2)/2
                if key not in hypotheses:
                    hypotheses[key]=(count,w,h)
    # The measured full outer edge (when present) is tried before summed edges.
    short_sums=[]
    for count in range(1,min(n,4)+1):
        short_sums.extend((sum(lengths[i] for i in combo),count) for combo in itertools.combinations(range(len(lengths)),count)
                          if 47<=sum(lengths[i] for i in combo)<=93)
    def size_rank(candidate):
        count,w,h=candidate
        support=min((c+abs(value-h)*2 for value,c in short_sums),default=10)
        return count+support,abs(w-100)
    hypotheses=sorted(hypotheses.values(),key=size_rank)
    start=time.perf_counter();expanded=0;solutions=[];final_seen=set();tries=0
    for _,w,h in hypotheses:
        if time.perf_counter()-start>seconds:
            break
        tries+=1
        hypothesis_start=time.perf_counter()
        def inside(q):
            box=bounds(q)
            return box[0]>=-1.3 and box[1]>=-1.3 and box[2]<=w+1.3 and box[3]<=h+1.3
        def outer_error(q):
            # The task explicitly guarantees a full outer edge for every piece.
            # Enforce that constraint, not merely a vertex touching the boundary.
            return min(max(abs(a[axis]-value),abs(b[axis]-value))
                       for a,b in zip(q,np.roll(q,-1,axis=0))
                       for axis,value in [(0,0.),(0,w),(1,0.),(1,h)])
        rectangle_corners=[np.array(v) for v in [(0.,0.),(w,0.),(0.,h),(w,h)]]
        corner_cache=[{i:[] for i in range(n)} for _ in range(4)]
        for i in range(n):
            for ang,t in corner_poses(source[i],w,h):
                q=transform(source[i],ang,t)
                if not inside(q) or outer_error(q)>1.5:
                    continue
                for k,corner in enumerate(rectangle_corners):
                    if np.min(np.linalg.norm(q-corner,axis=1))<.05:
                        corner_cache[k][i].append((ang,t,q))
        states=[(0.,{}, {})]
        completed=[];visited=set()
        def search(poses,polys,trail=()):
            nonlocal expanded
            if time.perf_counter()-start>seconds or time.perf_counter()-hypothesis_start>2.5 or len(completed)>96:
                return
            if len(poses)==n:
                completed.append((poses,polys,trail));return
            old=list(polys.values());next_states=[]
            def compatible(q):
                intersections=[overlap(q,p) for p in old]
                return not any(x>max(12.,.012*min(area(q),area(p))) for x,p in zip(intersections,old))
            uncovered=[k for k,c in enumerate(rectangle_corners)
                       if not any(cv2.pointPolygonTest(p.astype(np.float32),tuple(map(float,c)),True)>=-1.3 for p in old)]
            mandatory=None
            if uncovered:
                alternatives=[]
                for k in uncovered:
                    choices=[(i,ang,t,q) for i in range(n) if i not in poses
                             for ang,t,q in corner_cache[k][i] if compatible(q)]
                    if not choices:
                        return
                    alternatives.append(choices)
                mandatory=min(alternatives,key=len)
            streams=[]
            if mandatory is not None:
                streams=mandatory
            else:
                for i in range(n):
                    if i not in poses:
                        streams.extend((i,ang,t,transform(source[i],ang,t)) for ang,t in contact_poses(source[i],old))
            for i,angle,t,q in streams:
                if i in poses:
                    continue
                expanded+=1
                if not inside(q) or outer_error(q)>1.5 or not compatible(q):
                    if trace is not None and 'reject' not in trace and old:
                        trace['reject']=([p.copy() for p in old],q.copy(),(w,h))
                    continue
                intersections=[overlap(q,p) for p in old]
                newposes={**poses,i:(angle,t)}
                key=tuple((k,round(math.cos(v[0]),3),round(math.sin(v[0]),3),round(v[1][0],1),round(v[1][1],1)) for k,v in sorted(newposes.items()))
                if key in visited:
                    continue
                visited.add(key)
                newpolys={**polys,i:q}
                score=sum(intersections)*5+sum(outer_error(p) for p in newpolys.values())*.5
                next_states.append((score,newposes,newpolys))
            next_states.sort(key=lambda x:x[0])
            for branch,(_,pp,qq) in enumerate(next_states):
                next_trail = trail
                if trace is not None:
                    next_trail = (*trail, (branch, len(next_states), next_states[0 if branch else -1][2]))
                search(pp,qq,next_trail)
                if completed and not need_many:
                    return
                if time.perf_counter()-start>seconds or time.perf_counter()-hypothesis_start>2.5:
                    return
        for _,pp,qq in states:
            search(pp,qq)
            if completed and not need_many:
                break
            if time.perf_counter()-start>seconds or time.perf_counter()-hypothesis_start>2.5:
                break
        states=completed
        for poses,polys,trail in states:
            if len(poses)!=n:
                continue
            values=list(polys.values());err,dims=rectangle_error(values)
            if err>.035:
                continue
            if sum(overlap(values[i],values[j]) for i in range(n) for j in range(i))>total*.007:
                continue
            normalized=[poses[i] for i in range(n)]
            key=tuple((round(math.cos(ang),2),round(math.sin(ang),2),round(t[0],0),round(t[1],0)) for ang,t in normalized)
            if key in final_seen:
                continue
            final_seen.add(key);solutions.append((err,normalized))
            if trace is not None and ('path_score' not in trace or err < trace['path_score']):
                trace.update(path=list(polys.items()),size=(w,h),branches=trail,path_score=err)
        if solutions and (not need_many or len(solutions)>=20):
            break
    if not solutions:
        raise ValueError(f'在 {seconds:g}s 内未找到可靠拼接（{tries} 个尺寸假设，{expanded} 个接触候选）。未使用隐藏答案。')
    solutions.sort(key=lambda x:x[0])
    return solutions,{'method':'边长组合 + 面积估计矩形 + 边接触/角点约束回溯',
                      'expanded':expanded,'solutions':len(solutions),'rectangle_hypotheses':tries,
                      'geometry_error':round(solutions[0][0],5),'search_seconds':round(time.perf_counter()-start,3),'bounded_search':True}


def compose_candidate(detection,poses):
    polys=[transform(o.polygon,*pose) for o,pose in zip(detection.pieces,poses)]
    b=bounds(np.concatenate(polys)); size=np.maximum(12,np.ceil((b[2:]-b[:2])*3).astype(int))
    canvas=np.full((size[1],size[0],3),245,np.uint8)
    valid=np.zeros(canvas.shape[:2],np.uint8)
    for obs,(angle,t) in zip(detection.pieces,poses):
        mask=np.zeros(detection.rectified.shape[:2],np.uint8)
        cv2.fillPoly(mask,[np.round(obs.polygon*3).astype(np.int32)],255)
        matrix=np.column_stack([rotation(angle),(t-b[:2])*3]).astype(np.float32)
        patch=cv2.warpAffine(detection.rectified,matrix,tuple(size))
        pm=cv2.warpAffine(mask,matrix,tuple(size),flags=cv2.INTER_NEAREST)
        canvas[pm>0]=patch[pm>0]; valid[pm>0]=255
    return canvas,valid


def texture_score(detection,poses,template_bank,diagnostic=None):
    image,valid=compose_candidate(detection,poses)
    image=cv2.resize(image,(240,160),interpolation=cv2.INTER_AREA)
    valid=cv2.resize(valid,(240,160),interpolation=cv2.INTER_NEAREST)
    valid=cv2.erode(valid,np.ones((3,3),np.uint8))>0
    # Normalize global illumination without assuming a source pose or cut.
    image=np.clip(image.astype(float)*245/max(150,float(np.percentile(image[valid],90))),0,255)
    best=(float('inf'),-1)
    for i,template in enumerate(template_bank):
        target=cv2.resize(template,(240,160),interpolation=cv2.INTER_AREA).astype(float)
        for flipped in (False,True):
            ref=target[::-1,::-1] if flipped else target
            ink=(np.min(image,axis=2)<190)|(np.min(ref,axis=2)<190)
            selection=valid&ink
            error=float(np.mean(np.abs(image[selection]-ref[selection]))/255) if np.any(selection) else 1.
            if error<best[0]:
                best=(error,i)
                if diagnostic is not None:
                    diagnostic.update(image=image, reference=ref, selection=selection)
    return best


def make_actions(observations,poses,task,clearance_mm=1.6):
    local=[transform(o.polygon,*pose) for o,pose in zip(observations,poses)]
    if task!=1:
        box=bounds(np.concatenate(local)); mid=(box[:2]+box[2:])/2
        # Resolve every observed shared edge in its outward normal direction.
        # Radial centroid expansion alone fails for concave pieces/interlocks.
        constraints=[]
        for i,p in enumerate(local):
            for j,q in enumerate(local):
                if j<=i:
                    continue
                for a,b in zip(p,np.roll(p,-1,axis=0)):
                    u=b-a;length=np.linalg.norm(u);normal=np.array([u[1],-u[0]])/length
                    for c,d in zip(q,np.roll(q,-1,axis=0)):
                        v=d-c
                        if np.dot(u,v)/(length*np.linalg.norm(v))>-.97:
                            continue
                        distances=(np.array([c,d])-a)@normal
                        proj=(np.array([c,d])-a)@(u/length)
                        contact=min(length,max(proj))-max(0.,min(proj))
                        if contact>4 and max(abs(distances))<2.4:
                            constraints.append((i,j,normal,float(clearance_mm)-float(np.min(distances))))
        shifts=np.zeros((len(local),2))
        for _ in range(160):
            maximum=0.
            for i,j,normal,gap in constraints:
                deficit=gap-np.dot(shifts[j]-shifts[i],normal)
                if deficit>0:
                    shifts[i]-=normal*deficit*.5;shifts[j]+=normal*deficit*.5
                    maximum=max(maximum,deficit)
            if maximum<.001:
                break
        poses=[(ang,t+shifts[i]) for i,(ang,t) in enumerate(poses)]
        local=[transform(o.polygon,*pose) for o,pose in zip(observations,poses)]
        if any(overlap(local[i],local[j])>.3 for i in range(len(local)) for j in range(i)):
            raise ValueError('候选布局在预留边缘间隙后仍有重叠，拒绝执行搬运')
        box=bounds(np.concatenate(local)); shift=np.array([105.,223.])-(box[:2]+box[2:])/2
        poses=[(ang,t+shift) for ang,t in poses]
    actions=[]
    for obs,(angle,t) in zip(observations,poses):
        g=rotation(angle)@obs.grip+t
        target=transform(obs.polygon,angle,t)
        if np.any(target[:,0]<3) or np.any(target[:,0]>207) or np.any(target[:,1]<152) or np.any(target[:,1]>294):
            raise ValueError('目标位姿越过纸面或下半区安全边界')
        actions.append({'id':obs.id,'pick':obs.grip.tolist(),'place':g.tolist(),
                        'angle':float((angle+math.pi)%(2*math.pi)-math.pi),
                        'angle_deg':round(math.degrees((angle+math.pi)%(2*math.pi)-math.pi),2),
                        'target_polygon':target.tolist()})
    # Exact small-N empty-travel ordering; source/target regions do not intersect.
    def cost(order):
        current=np.array([10.,10.]); distance=0.
        for i in order:
            a=actions[i]; distance+=np.linalg.norm(np.array(a['pick'])-current)+np.linalg.norm(np.array(a['place'])-a['pick'])
            current=np.array(a['place'])
        return float(distance)
    order=min(itertools.permutations(range(len(actions))),key=cost)
    return [actions[i] for i in order],round(cost(order),2)


def solve(detection,task,template_bank=None,budget=12.,clearance_mm=1.6,trace=None):
    start=time.perf_counter()
    if not detection.pieces:
        raise ValueError('没有识别到碎片')
    if task==1:
        poses=[(0.,np.array([0.,148.5])) for _ in detection.pieces]
        info={'method':'只搬运到下半区，保留原相对摆放','solutions':1,'expanded':0}
    elif task==2:
        poses,info=fixed_solution(detection.pieces,trace)
    else:
        solutions,info=unknown_solutions(detection.pieces,budget,need_many=task==4,trace=trace)
        if task==4:
            if not template_bank:
                raise ValueError('当前扑克牌演示需要公开的自绘牌面模板库')
            ranked=[]
            for geom,pp in solutions:
                tex,idx=texture_score(detection,pp,template_bank)
                ranked.append((tex+geom*.4,tex,idx,pp))
            ranked.sort(key=lambda x:x[0]); _,tex,idx,poses=ranked[0]
            if trace is not None: trace['ranked']=ranked
            info.update({'texture_error':round(tex,5),'template_index':idx,'texture_prior':'4 张自绘牌面，模板无切割和摆放信息'})
            if tex>.30:
                raise ValueError(f'候选矩形的牌面匹配不足（误差 {tex:.3f}），拒绝把几何成功当作花纹成功')
        else:
            poses=solutions[0][1]
    if trace is not None: trace['poses']=poses
    actions,distance=make_actions(detection.pieces,poses,task,clearance_mm)
    if task in (2,3,4):
        from seam_audit import plan_seams
        for s in plan_seams([transform(o.polygon,*pose) for o,pose in zip(detection.pieces,poses)]):
            i,j=s['i'],s['j']
            s.update(i=detection.pieces[i].id,j=detection.pieces[j].id)
            next(a for a in actions if a['id']==s['i']).setdefault('seams',[]).append(s)
    info.update({'elapsed_seconds':round(time.perf_counter()-start,3),'travel_mm':distance,
                 'input':'仅轮廓、像素、题图先验；不含生成器坐标/切割/答案'})
    return actions,info
