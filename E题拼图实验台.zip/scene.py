"""Synthetic camera/virtual tabletop. Ground truth stays on this side of the API.

Neither vision.py nor solver.py imports this module. Captures are ordinary BGR
arrays; the actuator selects a physical piece by contact point, not detector ID.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import cv2
import numpy as np
from geometry import area, bounds, clean, clip_halfplane, contains, overlap, rotation, transform,separation

PAPER = (210., 297.)
SCALE = 3
RAW_SIZE = (1000, 1000)


def prescribed_pieces():
    # Official figure 2: top 20+80 mm, left 20+10+30 mm.
    # The diagonal (20,0)->(100,60) is 100 mm long; split marks are 20/30 mm.
    return [np.array(p, float) for p in [
        [(0,0),(20,0),(36,12),(0,20)],
        [(0,20),(36,12),(76,42),(0,30)],
        [(0,30),(76,42),(100,60),(0,60)],
        [(20,0),(100,0),(100,60)],
    ]]


def has_outer_edge(p, w, h):
    return any((np.allclose([a[0], b[0]], k, atol=1e-5) if axis == 0 else np.allclose([a[1], b[1]], k, atol=1e-5))
               for a,b in zip(p, np.roll(p,-1,axis=0)) for axis,k in [(0,0),(0,w),(1,0),(1,h)])


def unknown_pieces(rng, n=4, family='random'):
    if family == 'concave' and n >= 2:
        w, h = 110., 70.
        if n == 2:
            return [clean([[0,0],[110,0],[55,35],[110,70],[0,70]]), clean([[110,0],[110,70],[55,35]])], w,h
        polys = [clean([[0,0],[30,0],[30,70],[0,70]]), clean([[30,0],[110,0],[55,35],[110,70],[30,70]])]
        if n == 3:
            polys.append(clean([[110,0],[110,70],[55,35]]))
        else:
            polys.extend([clean([[110,0],[110,35],[55,35]]), clean([[110,35],[110,70],[55,35]])])
        return polys,w,h
    for _ in range(120):
        w, h = float(rng.uniform(100,110)), float(rng.uniform(65,78))
        polys = [np.array([[0,0],[w,0],[w,h],[0,h]])]
        for _cut in range(n-1):
            found = False
            for _ in range(180):
                order = np.argsort([-area(p) for p in polys])
                i = int(order[0 if rng.random() < .8 else int(rng.integers(len(order)))])
                p = polys[i]
                b = bounds(p)
                # Axis-aligned and oblique cuts, with no assumption of a 2x2 grid.
                angle = float(rng.choice([0, math.pi/2])) if rng.random() < .4 else float(rng.uniform(0, math.pi))
                normal = np.array([math.cos(angle),math.sin(angle)])
                proj = p @ normal
                off = float(rng.uniform(proj.min()+.25*np.ptp(proj), proj.max()-.25*np.ptp(proj)))
                a,bp = clip_halfplane(p,normal,off), clip_halfplane(p,normal,off,False)
                if not all(3 <= len(q) <= 5 and area(q)>400 and np.min(np.linalg.norm(np.roll(q,-1,axis=0)-q,axis=1)) >= 20.2 and has_outer_edge(q,w,h) for q in [a,bp]):
                    continue
                polys[i:i+1] = [a,bp]
                found = True
                break
            if not found:
                break
        if len(polys) == n:
            return polys,w,h
    raise RuntimeError('Could not generate a valid cut; use another seed')


def card_texture(width, height, variant=0):
    """Original procedural court-card illustration, not downloaded artwork.

    The same small, public template family is available to the recognizer. It
    contains artwork ONLY, never cut polygons, source poses, or an answer.
    """
    w,h = int(round(width*SCALE)),int(round(height*SCALE))
    img = np.full((h,w,3),245,np.uint8)
    red=(45,40,185); dark=(50,48,52); gold=(80,165,210); blue=(170,85,45)
    ink = red if variant % 2 == 0 else dark
    cv2.rectangle(img,(int(.08*w),int(.08*h)),(int(.92*w),int(.92*h)),ink,2)
    cv2.putText(img,'K' if variant<2 else 'Q',(int(.10*w),int(.25*h)),cv2.FONT_HERSHEY_SIMPLEX,.7,ink,2,cv2.LINE_AA)
    cv2.putText(img,'K' if variant<2 else 'Q',(int(.80*w),int(.88*h)),cv2.FONT_HERSHEY_SIMPLEX,.7,ink,2,cv2.LINE_AA)
    for flip in [False,True]:
        layer=np.full_like(img,245)
        pts=np.array([[.33,.50],[.37,.31],[.44,.25],[.56,.25],[.63,.32],[.68,.5]])*np.array([w,h])
        cv2.fillPoly(layer,[pts.astype(np.int32)],blue if variant%2 else red)
        face=np.array([[.43,.27],[.43,.16],[.56,.16],[.57,.27],[.51,.32]])*np.array([w,h])
        cv2.fillPoly(layer,[face.astype(np.int32)],(175,205,226))
        crown=np.array([[.40,.17],[.40,.08],[.46,.12],[.50,.07],[.54,.12],[.61,.08],[.60,.17]])*np.array([w,h])
        cv2.fillPoly(layer,[crown.astype(np.int32)],gold)
        cv2.line(layer,(int(.44*w),int(.20*h)),(int(.48*w),int(.20*h)),dark,2)
        cv2.line(layer,(int(.53*w),int(.20*h)),(int(.56*w),int(.20*h)),dark,2)
        for k in range(5):
            cv2.line(layer,(int((.36+.055*k)*w),int(.48*h)),(int((.40+.045*k)*w),int(.32*h)),gold,2)
        cv2.line(layer,(int(.27*w),int(.48*h)),(int(.30*w),int(.14*h)),dark,3)
        cv2.line(layer,(int(.27*w),int(.48*h)),(int(.30*w),int(.14*h)),gold,1)
        if flip:
            layer=cv2.flip(layer,-1)
        mask=np.any(layer<230,axis=2)
        img[mask]=layer[mask]
    return img


@dataclass
class PhysicalPiece:
    polygon: np.ndarray
    texture: np.ndarray
    angle: float
    translation: np.ndarray
    moved: bool=False

    def world(self):
        return transform(self.polygon,self.angle,self.translation)


class Scene:
    def __init__(self, task=2, seed=12, count=4, family='random', noise=1.2, slip=.25):
        self.task,self.seed,self.noise,self.slip = int(task),int(seed),float(noise),float(slip)
        self.rng=np.random.default_rng(seed)
        self.capture_index=0
        self.moves=[]
        if task in (1,2):
            polygons,w,h=prescribed_pieces(),100.,60.
        else:
            polygons,w,h=unknown_pieces(self.rng,int(count),family)
        self.width,self.height=w,h
        self.variant=int(self.rng.integers(4))
        texture=card_texture(w,h,self.variant) if task==4 else np.full((round(h*SCALE),round(w*SCALE),3),245,np.uint8)
        self.pieces=[]
        for p in sorted(polygons,key=lambda q:-area(q)):
            placed=False
            for _ in range(3000):
                theta=float(self.rng.uniform(-math.pi,math.pi))
                q=transform(p,theta,[0,0]); b=bounds(q)
                if b[2]-b[0] > 196 or b[3]-b[1] > 133:
                    continue
                low=np.array([7,7])-b[:2]; high=np.array([203,140])-b[2:]
                if np.any(high<low):
                    continue
                t=self.rng.uniform(low,high)
                q=q+t
                # Leave a visible blue gap between independent source pieces.
                expanded=(q-q.mean(0))*1.07+q.mean(0)
                if any(overlap(expanded,other.world())>.01 for other in self.pieces):
                    continue
                if any(separation(q,other.world())<3. for other in self.pieces):
                    continue
                self.pieces.append(PhysicalPiece(clean(p),texture.copy(),theta,t))
                placed=True
                break
            if not placed:
                # Retry packing only; cut geometry stays independent of detection.
                self.__init__(task,seed+100003,count,family,noise,slip)
                return
        jitter=self.rng.normal(0,10,(4,2))
        corners=np.float32([[230,60],[770,90],[835,925],[160,900]])+jitter.astype(np.float32)
        source=np.float32([[0,0],[210*SCALE-1,0],[210*SCALE-1,297*SCALE-1],[0,297*SCALE-1]])
        self._camera=cv2.getPerspectiveTransform(source,corners)

    def render(self, calibration=False):
        plane=np.full((round(PAPER[1]*SCALE),round(PAPER[0]*SCALE),3),(174,86,25),np.uint8)
        if calibration:
            for y in (20,148,277):
                for x in (20,105,190):
                    cv2.circle(plane,(round(x*SCALE),round(y*SCALE)),round(3*SCALE),(245,245,245),-1,cv2.LINE_AA)
        else:
            cv2.line(plane,(0,round(148.5*SCALE)),(plane.shape[1]-1,round(148.5*SCALE)),(40,40,40),round(1.5*SCALE))
            for p in self.pieces:
                mask=np.zeros(p.texture.shape[:2],np.uint8)
                cv2.fillPoly(mask,[np.round(p.polygon*SCALE).astype(np.int32)],255)
                r=rotation(p.angle)
                affine=np.column_stack([r,p.translation*SCALE]).astype(np.float32)
                patch=cv2.warpAffine(p.texture,affine,(plane.shape[1],plane.shape[0]),flags=cv2.INTER_LINEAR)
                pm=cv2.warpAffine(mask,affine,(plane.shape[1],plane.shape[0]),flags=cv2.INTER_NEAREST)
                plane[pm>0]=patch[pm>0]
        background=np.full((RAW_SIZE[1],RAW_SIZE[0],3),(55,49,44),np.uint8)
        warped=cv2.warpPerspective(plane,self._camera,RAW_SIZE,flags=cv2.INTER_LINEAR)
        pm=cv2.warpPerspective(np.full(plane.shape[:2],255,np.uint8),self._camera,RAW_SIZE)
        background[pm>240]=warped[pm>240]
        yy,xx=np.indices(background.shape[:2])
        illumination=.91+.07*xx/RAW_SIZE[0]+.06*yy/RAW_SIZE[1]
        frame=background.astype(np.float32)*illumination[:,:,None]
        rng=np.random.default_rng(self.seed*97+self.capture_index)
        self.capture_index+=1
        frame+=rng.normal(0,self.noise,frame.shape)
        return cv2.GaussianBlur(np.clip(frame,0,255).astype(np.uint8),(3,3),.35)

    def place(self, action, perturb=None):
        pick=np.array(action['pick'],float)
        hits=[p for p in self.pieces if contains(p.world(),pick)]
        if len(hits)!=1:
            raise RuntimeError('Virtual pickup did not touch exactly one piece; perception/calibration must be checked')
        p=hits[0]
        material_point=(pick-p.translation) @ rotation(p.angle)
        delta=float(action['angle'])
        error=self.slip if perturb is None else float(perturb)
        p.angle+=delta+float(self.rng.normal(0,error*.004))
        p.translation=np.array(action['place'],float)+self.rng.normal(0,error,2)-rotation(p.angle)@material_point
        p.moved=True
        self.moves.append({'observed_id':action['id'],'error_sigma_mm':error})

    def physical_metrics(self):
        """Diagnostic oracle ONLY: never passed to perception or planning."""
        polys=[p.world() for p in self.pieces]
        return {'oracle_overlap_mm2':sum(overlap(polys[i],polys[j]) for i in range(len(polys)) for j in range(i)),
                'oracle_all_lower':all(np.min(p[:,1])>=148.5 for p in polys)}
